var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var inquiry_exports = {};
__export(inquiry_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(inquiry_exports);
var import_client = require("@notionhq/client");
const notion = new import_client.Client({ auth: process.env.NOTION_API_KEY });
const NOTION_DB = process.env.NOTION_INQUIRY_DB_ID || process.env.NOTION_INQUIRIES_DB;
const CUSTOMERIO_CDP_KEY = process.env.CUSTOMERIO_CDP_KEY || process.env.CUSTOMERIO_SITE_ID;
function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
}
function deriveSegment(deployment_type, use_case) {
  const dt = (deployment_type || "").toLowerCase();
  const uc = (use_case || "").toLowerCase();
  if (dt.includes("clinical") || uc.includes("mental health") || uc.includes("healthcare")) {
    return "mental-health-ai";
  }
  if (dt.includes("customer support") || uc.includes("customer support")) {
    return "customer-support-ai";
  }
  if (dt.includes("hr") || dt.includes("workforce") || uc.includes("enterprise copilot")) {
    return "enterprise-ai";
  }
  return "human-facing-ai";
}
function mapScenarioVolumeToEngagementType(v) {
  if (!v) return "Unsure";
  if (v.startsWith("25")) return "Snapshot";
  if (v.startsWith("50") || v.startsWith("79") || v.startsWith("100")) return "Audit";
  return "Unsure";
}
async function pushToCustomerIO(data) {
  if (!CUSTOMERIO_CDP_KEY) {
    console.warn("CUSTOMERIO_CDP_KEY not set \u2014 skipping CIO push");
    return;
  }
  const authHeader = "Basic " + Buffer.from(`${CUSTOMERIO_CDP_KEY}:`).toString("base64");
  const email = (data.work_email || data.email || "").toLowerCase().trim();
  const segment = deriveSegment(data.deployment_type, data.use_case);
  const nameParts = (data.name || "").split(" ");
  const identifyRes = await fetch("https://cdp.customer.io/v1/identify", {
    method: "POST",
    headers: { Authorization: authHeader, "Content-Type": "application/json" },
    body: JSON.stringify({
      userId: email,
      traits: {
        email,
        first_name: nameParts[0] || data.name,
        last_name: nameParts.slice(1).join(" ") || "",
        company: data.company,
        role: data.role_title || data.role || "",
        segment,
        system_type: data.deployment_type || "",
        use_case: data.use_case || "",
        scenario_volume: data.scenario_volume || "",
        engagement_model: data.engagement_model || "",
        industry: data.industry || "",
        region: data.region || "",
        company_size: data.company_size || "",
        lead_source: "inbound_inquiry"
      }
    })
  });
  if (!identifyRes.ok) {
    console.error("CIO identify failed:", identifyRes.status, await identifyRes.text());
  }
  const eventRes = await fetch("https://cdp.customer.io/v1/track", {
    method: "POST",
    headers: { Authorization: authHeader, "Content-Type": "application/json" },
    body: JSON.stringify({
      userId: email,
      event: "inquiry_submitted",
      properties: {
        segment,
        use_case: data.use_case || "",
        deployment_type: data.deployment_type || "",
        scenario_volume: data.scenario_volume || "",
        engagement_model: data.engagement_model || "",
        company: data.company
      }
    })
  });
  if (!eventRes.ok) {
    console.error("CIO event failed:", eventRes.status, await eventRes.text());
  }
}
async function pushToNotion(data) {
  if (!NOTION_DB) {
    console.warn("NOTION_INQUIRY_DB_ID / NOTION_INQUIRIES_DB not set \u2014 skipping Notion push");
    return null;
  }
  const email = data.work_email || data.email || "";
  const detailsText = [
    data.system_and_concerns || data.details || "",
    data.use_case ? `

Use case: ${data.use_case}` : "",
    data.deployment_type ? `
Deployment type: ${data.deployment_type}` : "",
    data.scenario_volume ? `
Scenario volume: ${data.scenario_volume}` : "",
    data.engagement_model ? `
Engagement model: ${data.engagement_model}` : "",
    data.industry ? `
Industry: ${data.industry}` : "",
    data.region ? `
Region: ${data.region}` : "",
    data.company_size ? `
Company size: ${data.company_size}` : "",
    data.deadline ? `
Deadline: ${data.deadline}` : "",
    `
Segment: ${deriveSegment(data.deployment_type, data.use_case)}`
  ].join("").trim();
  const response = await notion.pages.create({
    parent: { database_id: NOTION_DB },
    properties: {
      // ── Stable Notion DB property names ──
      "Name": {
        title: [{ text: { content: data.name } }]
      },
      "Email": {
        email
      },
      "Organization": {
        rich_text: [{ text: { content: data.company || "" } }]
      },
      "Role": {
        rich_text: [{ text: { content: data.role_title || data.role || "" } }]
      },
      "Product Description": {
        rich_text: [{ text: { content: `${data.deployment_type || ""} \u2014 ${data.company || ""}` } }]
      },
      "Product Stage": {
        // New form doesn't capture deployment_stage; default to Pre-launch
        select: { name: "Pre-launch" }
      },
      "Engagement Type": {
        select: { name: mapScenarioVolumeToEngagementType(data.scenario_volume) }
      },
      "Source": {
        select: { name: "Website Form" }
      },
      "Details": {
        rich_text: [{ text: { content: detailsText.slice(0, 2e3) } }]
      },
      "Status": {
        select: { name: "New" }
      },
      "Submitted": {
        date: { start: (/* @__PURE__ */ new Date()).toISOString() }
      }
    }
  });
  return response.id;
}
const handler = async (event) => {
  const headers = corsHeaders();
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  }
  let data;
  try {
    data = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "Invalid JSON body" }) };
  }
  const email = data.work_email || data.email || "";
  if (!data.name || !String(data.name).trim()) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "Missing required field: name" }) };
  }
  if (!email.trim()) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "Missing required field: work_email" }) };
  }
  if (!data.company || !String(data.company).trim()) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "Missing required field: company" }) };
  }
  const [notionResult] = await Promise.allSettled([
    pushToNotion(data),
    pushToCustomerIO(data)
  ]);
  if (notionResult.status === "rejected") {
    console.error("Notion write failed:", notionResult.reason);
  }
  return {
    statusCode: 200,
    headers,
    body: JSON.stringify({
      success: true,
      message: "Inquiry submitted successfully",
      id: notionResult.value || null
    })
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
