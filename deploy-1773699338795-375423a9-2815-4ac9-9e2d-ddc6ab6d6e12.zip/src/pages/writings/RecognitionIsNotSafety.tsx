import PageShell from "@/components/PageShell";
import PageMeta from "@/components/PageMeta";
import SummaryHero from "@/components/SummaryHero";
import ArchiveBanner from "@/components/ArchiveBanner";

export default function RecognitionIsNotSafety() {
  return (
    <PageShell>
      <PageMeta
        title="Recognition Is Not Safety | Ikwe.ai"
        description="Founder writing abstract on the distinction between emotional recognition and behavioral safety outcomes."
        path="/archive/research/writings/recognition-is-not-safety"
        ogImagePath="/og/problem.png"
      />
      <ArchiveBanner type="library" />
      <SummaryHero
        kicker="Research Note"
        title="Recognition Is Not Safety"
        summary="A system can correctly recognize distress and still choose unsafe behavior. Recognition quality and safety quality are related but not equivalent."
        highlights={[
          "Recognition does not equal safe response",
          "Behavior quality is measured separately",
          "Research note with governance framing",
        ]}
        primaryAction={{ href: "/research/writings", label: "Back to Writing Library" }}
        secondaryAction={{ href: "/research", label: "Back to Research" }}
        jumpLinks={[
          { href: "#research-note", label: "Research Note" },
          { href: "#author", label: "Author" },
        ]}
      />

      <section id="research-note" className="py-14 border-b border-border max-w-3xl article-reading">
        <p className="section-kicker mb-6">Research Note</p>
        <p className="text-sm text-foreground-muted leading-relaxed mb-5">
          A system can correctly detect emotional distress and still fail at behavioral safety. Recognition quality and
          safety quality are related, but they are not the same control objective.
        </p>
        <p className="text-sm text-foreground-muted leading-relaxed mb-5">
          Institutional review should separate these signals: one dimension measures recognition, and another measures
          behavioral response quality under risk-sensitive conditions.
        </p>
        <p className="text-sm text-foreground-muted leading-relaxed">
          The governance implication is practical: recognition metrics and response-safety metrics must be tracked
          independently so organizations can see detection quality and intervention quality as separate controls.
        </p>
      </section>

      <section id="author" className="py-14 max-w-3xl">
        <p className="text-xs text-foreground-subtle">By Stephanie Stranko</p>
      </section>
    </PageShell>
  );
}
